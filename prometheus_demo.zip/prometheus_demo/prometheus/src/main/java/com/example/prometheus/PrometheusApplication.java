package com.example.prometheus;

import java.util.Arrays;

import javax.servlet.Servlet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

import io.prometheus.client.CollectorRegistry;
import io.prometheus.client.exporter.MetricsServlet;

@SpringBootApplication
public class PrometheusApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrometheusApplication.class, args);
	}

	@SuppressWarnings("unchecked")
	@Bean
	ServletRegistrationBean<Servlet> registerPrometheusExporterServlet(CollectorRegistry metricRegistry) {
	    @SuppressWarnings("rawtypes")
		ServletRegistrationBean srb = new ServletRegistrationBean();
	    srb.setServlet(new MetricsServlet(metricRegistry));
	    srb.setUrlMappings(Arrays.asList("/java_app"));
	    return srb;
	}
}
