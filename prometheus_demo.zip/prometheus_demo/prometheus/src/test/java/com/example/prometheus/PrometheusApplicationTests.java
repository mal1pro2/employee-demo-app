package com.example.prometheus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrometheusApplicationTests {

	@Test
	void contextLoads() {
	}

}
